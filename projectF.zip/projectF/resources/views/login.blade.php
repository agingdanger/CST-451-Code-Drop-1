<h1>Login</h1>

<form  action="loginHandler" method="POST">
            User <br><label>
            <input type="text" name="userr" size="40" id = "uzer">
        </label><br>
            Password <br><label>
            <input type="password" name="pass" size="40" id = "pazz">
        </label><br>
            <input id="button" type="submit" name="submit" value="Log-In">
</form>