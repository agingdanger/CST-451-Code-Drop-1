<h1>Register</h1>
			<form action="registrationHandler" method="post">
				<div>
					<div>
						Username:<br> <input type="text" name="username" class="input" required="required">
					</div>
					<div>
						Password:<br> <input type="password" name="password" class="input" required="required">
					</div>
					<div> 
						First Name:<br> <input type="text" name="firstName" class="input" required="required">
					</div>
					<div>
						Last Name:<br> <input type="text" name="lastName" class="input" required="required">
					</div>
					<div>
						Email:<br> <input type="email" name="email" class="input" required="required">
					</div>
					<div>
						Phone:<br> <input type="text" name="phone" class="input" required="required">
					</div>
					<div>
						Role:<br> <input type="text" name="phone" class="input" required="required">
					</div>
					
					
					
				</div>
				<div>
					<button type="submit" class="button">
						Register
					</button>
					<p>
						Already registered? click<a href="login">here</a>to login!
					</p>
				</div>
			</form>
