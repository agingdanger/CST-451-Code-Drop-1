<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
/**
 * 
 * @author Charles
 * Controller to handle all user functions
 *
 */
class UserController extends Controller
{
    //returns the view of registration
    public function index(Request $request){
        return view('welcome');
    }
    
    //takes the registration request and will eventually attempt to add a user
    public function registration(Request $request){
       
//         $user = new User(0, $request->input('username'), $request->input('password'),
//         $request->input('firstName'), $request->input('lastName'), $request->input('email'), $request->input('phone'), $request->input('role'));
        
        echo "Test";
    }
    
    //take the login request and will eventually login a user
    public function login(Request $request){
        return view('login');
    }
    
    
    
}