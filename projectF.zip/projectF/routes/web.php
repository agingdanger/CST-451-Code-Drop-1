<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::group(['middleware' => 'auth'], function () {
//     Route::get('/', function () {
//         return view('welcome');
//     });
// });

//Pulls users from the database
Route::get('pullUsers', function () {
    
    $users = DB::table("users")->get();
    
    dd($users);
    
});

//Route to registration page
Route::get('/registration', function () {
    return view('registration');
});

//Route to login page
Route::get('/login', function () {
    return view('login');
});

//Route to home page
Route::get('/home', function () {
    return view('welcome');
});

//Sends user to home through the controller
Route::get('home', 'UserController@index');

//Will handle the registration through the user controller
Route::post('registrationHandler', 'UserController@registration');

//Will handle the login through the user controller
Route::get('loginHandler', 'UserController@login');